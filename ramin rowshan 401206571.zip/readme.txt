7L6K
https://www.rcsb.org/structure/7L6K
PDB DOI:  https://doi.org/10.2210/pdb7L6K/pdbBMRB: 30832


txt file contain code for part that we don't need to write tcl file.
